<footer style="text-align:center; margin-top:40px; color:#888;">
<p>&copy; <?= date('Y') ?> <?= __('city_hospital') ?></p>
</footer>
