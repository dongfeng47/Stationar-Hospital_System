<footer class="auth-footer404">
<div class="auth-footer-container404">
 <p>&copy; <?= date('Y') ?> <?= __('app_name') ?>. <?= __('all_rights_reserved') ?></p>
</div>
</footer>
