<header class="auth-header404">
<div class="auth-header-container404">
 <img src="public/assets/icons/app_logo_icon.png" alt="Logo" class="auth-logo404">
<h1><?= __('app_name') ?></h1>
 </div>
</header>
