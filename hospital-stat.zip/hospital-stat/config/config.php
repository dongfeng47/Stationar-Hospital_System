<!-- 
$host = 'localhost';
$dbname = 'hospital_stat';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
} -->
